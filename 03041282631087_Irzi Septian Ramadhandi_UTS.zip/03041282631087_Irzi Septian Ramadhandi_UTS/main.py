#list
data_level = [18, 25, 33, 41, 55, 62, 76, 84, 91, 47, 29, 38, 70, 82, 15,
              12, 30, 50, 80, 95] #tambahan 5

#Rata-rata

def rata_rata(data):
    total = 0
    for nilai in data:
        total += nilai
    return total / len(data)

def kategori_status(status):
    if status > 80:
        return "HIGH"
    elif status >= 30:
        return "NORMAL"
    else:
        return "LOW"

#Hitung kategori

def hitung_kategori(data):
    jumlah = {"HIGH": 0, "NORMAL": 0, "LOW": 0}


    for level in data:
        status = kategori_status(level)
        jumlah[status] += 1

    return jumlah

print("===== MONITORING LEVEL TANGKI =====")

for angka, nilai in enumerate(data_level, start=1):
    status = kategori_status(nilai)
    print(f"{angka:02d}. Nilai = {nilai}% -> {status}")

rata = rata_rata(data_level)
maksimum = max(data_level)
minimum = min(data_level)
hasil   = hitung_kategori(data_level)




print("===== RINGKASAN =====")

print("Total data :", len(data_level))
print("LOW        :", hasil["LOW"])
print("NORMAL     :", hasil["NORMAL"])
print("HIGH       :", hasil["HIGH"])
print("Rata-rata :", f"{rata:.2f}", "%")
print("Maksimum  :", f"{maksimum:}", "%")
print("Minimum   :", f"{minimum}", "%")

print()
print("===== TESTING =====")
data_test = [29, 30, 31, 79, 80, 81, 18, 91]

for angka, nilai in enumerate(data_test, start=1):
    status = kategori_status(nilai)
    print(f"{angka}. Nilai = {nilai}% -> {status}")

print("===== SELESAI =====")





